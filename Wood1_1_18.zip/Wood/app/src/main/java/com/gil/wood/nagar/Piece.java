package com.gil.wood.nagar;



public class Piece {
    public double size;

    public Piece(double size) {
        this.size = size;
    }
}
